Fonts are the exact Latin faces used in the Reel, decompressed from the installed WOFF2 files into desktop-installable TTF format. Glyphs and typography are unchanged. Their SIL Open Font Licenses are included. Install the TTFs with your operating system and restart CapCut if necessary.

Branding, stickers and screenshots are supplied project assets, not newly generated artwork. Original images remain in 07_remotion_source/public/assets/. PNG conversions preserve original pixels and transparency. The supplied Orpheus and Heidi Laptops illustration has an opaque background and is marked as such in the asset manifest; it is not used in the current Reel. All other sticker overlay exports retain supplied alpha. Full notebook backgrounds and project screenshots are intentionally opaque.

Foley source provenance and CC0 licenses are in SFX_CATALOG.md and SFX_INVENTORY.json. For working relative source links, open the copies in 07_remotion_source/docs/.
