# Editable Remotion source snapshot

This contains the existing six scenes, original uploaded assets, recorded voiceover, Foley sources, timing configuration and export tools. No node_modules or render caches are bundled. The complete current renders are in ../01_full_reel/. Previous renders remain in the feature branch repository.

Preview/render composition: `HackistanReelVoiceover`. Runtime dependencies are pinned in video/package-lock.json. The original HackistanReel and HackistanReelSfx compositions retain the 60-second versions. The export-only HandoffAsset still does not change any video composition.

An agent or developer can install dependencies in video/ and run `npm run studio` or `npm run voiceover`. CapCut editing does not require running any of these commands.
