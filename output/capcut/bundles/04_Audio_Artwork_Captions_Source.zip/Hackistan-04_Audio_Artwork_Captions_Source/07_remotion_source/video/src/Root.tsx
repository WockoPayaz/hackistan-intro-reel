import {Composition,Still} from 'remotion';
import {HandoffAsset} from './HandoffAssets';
import {NarratedReel,NarratedVisuals,CaptionCard} from './NarratedReel';
import narrationTiming from './narration-timing.json';
import {Hook,Meet,Projects,Create,Opportunities,Join} from './scenes';
import './style.css';
import {FullReel} from './FullReel';
import {SfxLayer} from './SfxLayer';
const ReelWithSfx=()=> <><FullReel/><SfxLayer/></>;
import {ProjectsPrototype} from './ProjectsPrototype';
// Full silent Reel, approved storyboards, and retained Scene 3 motion prototype.
export const Root=()=> <>
 <Still id="HandoffAsset" component={HandoffAsset} defaultProps={{kind:"material",scene:0,layer:0,name:"masking-tape"}} width={1080} height={1920}/>
 <Composition id="HackistanNarratedVisuals" component={NarratedVisuals} width={1080} height={1920} fps={30} durationInFrames={narrationTiming.durationFrames}/>
 <Still id="NarrationCaption" component={CaptionCard} defaultProps={{text:""}} width={1080} height={1920}/>
 <Composition id="HackistanReelVoiceover" component={NarratedReel} width={1080} height={1920} fps={30} durationInFrames={narrationTiming.durationFrames}/>
 <Composition id="HackistanReelSfx" component={ReelWithSfx} width={1080} height={1920} fps={30} durationInFrames={1800}/>
 <Composition id="HackistanReel" component={FullReel} width={1080} height={1920} fps={30} durationInFrames={1800}/>
 <Composition id="Scene3Prototype" component={ProjectsPrototype} width={1080} height={1920} fps={30} durationInFrames={390}/>
 <Composition id="StoryboardPreview" component={Hook} width={1080} height={1920} fps={30} durationInFrames={30}/>
 <Still id="01-hook" component={Hook} width={1080} height={1920}/>
 <Still id="02-meet" component={Meet} width={1080} height={1920}/>
 <Still id="03-projects" component={Projects} width={1080} height={1920}/>
 <Still id="04-create" component={Create} width={1080} height={1920}/>
 <Still id="05-opportunities" component={Opportunities} width={1080} height={1920}/>
 <Still id="06-join" component={Join} width={1080} height={1920}/>
</>;
